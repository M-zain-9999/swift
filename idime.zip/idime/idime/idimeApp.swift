//
//  idimeApp.swift
//  idime
//
//  Created by Zain Ilyas on 16/03/2024.
//

import SwiftUI

@main

struct idimeApp: App {
    @StateObject var order = Order()
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(order)
        }
    }
}
