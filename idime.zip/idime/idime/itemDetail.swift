//
//  itemDetail.swift
//  idime
//
//  Created by Zain Ilyas on 17/03/2024.
//

import SwiftUI

struct itemDetail: View {
    @EnvironmentObject var order: Order
    let item : MenuItem
    var body: some View {
        VStack
        {
            ZStack(alignment: .bottomTrailing){
                Image(item.mainImage)
                    .resizable()
                    .scaledToFit()
        
                Text("Photo: \(item.photoCredit)")
                    .padding(4)
                    .background( .black)
                    .font(.caption)
                    .foregroundColor(.white)
                    .offset(x: -5 , y: -5)
            }
            Text(item.description)
                .padding()
            Button("Order this"){
                order.add(item: item)
            }
            .buttonStyle(.borderedProminent)
            
            Spacer()
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
    }
    
    struct itemDetail_Previews: PreviewProvider {
        static var previews: some View {
            NavigationStack{
                
                itemDetail(item: MenuItem.example)
                    .environmentObject(Order())
            }
        }
    }
}
