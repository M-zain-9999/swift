//
//  PaymentView.swift
//  idime
//
//  Created by Zain Ilyas on 17/03/2024.
//

import SwiftUI

struct PaymentView: View {
    @EnvironmentObject var order: Order
    var paymentTypes = ["cash", "credit-card", "app-points"]
    @State  private var paymentType = "Cash"
    var body: some View {
        VStack {
            Section {
                Picker("How do you want to pay", selection: $paymentType)
                {
                    ForEach(paymentTypes, id: \.self){
                        Text($0)
                    }
                }
            }
        }
        .navigationTitle("Payment")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    struct PaymentView_Previews: PreviewProvider {
        static var previews: some View {
            PaymentView()
                .environmentObject(Order ())        }
    }
}

