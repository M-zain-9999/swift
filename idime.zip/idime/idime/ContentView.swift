//
//  ContentView.swift
//  idime
//
//  Created by Zain Ilyas on 16/03/2024.
//

import SwiftUI

struct ContentView: View {
    let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")
    var body: some View {
        NavigationStack {
            List
            {
                ForEach(menu) { section in
                    Section(section.name) {
                        ForEach(section.items) { item in
                            NavigationLink (value: item){
                            itemRow(item: item)
                        }
                        }
                    }
                }
            }
            .navigationDestination(for: MenuItem.self) { item in
                itemDetail(item: item)
            }
                .navigationTitle("Menu")
                .listStyle(.grouped)
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
