//
//  OrderView.swift
//  idime
//
//  Created by Zain Ilyas on 17/03/2024.
//

import SwiftUI

struct OrderView: View {
    @EnvironmentObject var order: Order
    var body: some View {
//        NavigationStack{
            List {
                Section {
                    ForEach(order.items){item in
                        HStack {
                            Text(item.name)
                            Text("price is $\(item.price)")
                        }
                    }
                }
                Section{
                    NavigationLink("Place order") {
                        Text("check out")
                    }
                }
            }
                
//        }
//        .navigationTitle("Order")
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView()
            .environmentObject(Order())
    }
}
