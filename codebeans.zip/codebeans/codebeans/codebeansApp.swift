//
//  codebeansApp.swift
//  codebeans
//
//  Created by Zain Ilyas on 18/03/2024.
//

import SwiftUI

@main
struct codebeansApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
