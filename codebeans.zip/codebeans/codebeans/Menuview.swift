//
//  Menuview.swift
//  codebeans
//
//  Created by Zain Ilyas on 18/03/2024.
//

import SwiftUI

struct Menuview: View {
    
    @EnvironmentObject var menu: Menu
    
    let colums = [
        GridItem(.adaptive(minimum: 150))
    ] 
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Menuview_Previews: PreviewProvider {
    static var previews: some View {
        Menuview()
    }
}
