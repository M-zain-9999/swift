//
//  ContentView.swift
//  codebeans
//
//  Created by Zain Ilyas on 18/03/2024.
//

import SwiftUI

struct ContentView: View {
    @StateObject var menu = Menu()
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
